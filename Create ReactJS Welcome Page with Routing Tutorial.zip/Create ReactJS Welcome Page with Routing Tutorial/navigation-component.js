class Navigation extends Component {

state = {
    isOpen:'',
};

constructor( props ) {
    super( props );
    this.setState( {
        isOpen : false,
    } );
}

toggleCollapse = () => {
    this.setState( { isOpen : !this.state.isOpen } )
};


render() {
    return (
        <React.Fragment>
            <MDBNavbar color="yellow" light expand="md" className='mb-3'>
                <MDBNavbarBrand href="/">
                    <strong className="">App Name</strong>
                </MDBNavbarBrand>
                <MDBNavbarToggler onClick={ this.toggleCollapse }/>
                <MDBCollapse id="navbarCollapse3" isOpen={ this.state.isOpen } navbar>
                    <MDBNavbarNav left>
                        <MDBNavItem active>
                            <MDBNavLink to="/home">Home</MDBNavLink>
                        </MDBNavItem>
                        <MDBNavItem >
                            <MDBNavLink to="/colours">Colours</MDBNavLink>
                        </MDBNavItem>
                        <MDBNavItem>
                            <MDBNavLink to="/pens">Pens</MDBNavLink>
                        </MDBNavItem>
                        <MDBNavItem>
                            <MDBDropdown>
                                <MDBDropdownToggle nav caret>
                                    <span className="mr-2">Members</span>
                                </MDBDropdownToggle>
                                <MDBDropdownMenu>
                                    <MDBDropdownItem href="#!">Profile</MDBDropdownItem>
                                    <MDBDropdownItem href="#!">Login</MDBDropdownItem>
                                    <MDBDropdownItem href="#!">Logout</MDBDropdownItem>
                                    <MDBDropdownItem href="#!">Register</MDBDropdownItem>
                                </MDBDropdownMenu>
                            </MDBDropdown>
                        </MDBNavItem>
                    </MDBNavbarNav>
                    <MDBNavbarNav right>
                        <MDBNavItem>
                            <MDBFormInline waves>
                                <div className="md-form my-0">
                                    <input className="form-control mr-sm-2"
                                           type="text"
                                           placeholder="Search"
                                           aria-label="Search"/>
                                </div>
                            </MDBFormInline>
                        </MDBNavItem>
                    </MDBNavbarNav>
                </MDBCollapse>
            </MDBNavbar>
        </React.Fragment>
    );
}